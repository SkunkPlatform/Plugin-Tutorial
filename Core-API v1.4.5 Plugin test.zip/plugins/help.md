# Core Plugins

The Plugins folder is made for **Core Plugins**.

## Steps to Create a New Plugin

1. **Create a New Plugin Folder**:
   - In your Plugins directory, create a new folder for your plugin.

2. **Add JavaScript and JSON Files**:
   - In your plugin folder, add one of the following JavaScript files: `index.js`, `main.js`, or `plugin.js`.
   - Add a `plugin.json` file.

3. **Write the `plugin.json`**:
   - Use the following template for your `plugin.json` file:
     ```json
     {
         "name": "Your Plugin here",
         "description": "Your Description here",
         "version": "v1.0"
     }
     ```

4. **Save All Changes**:
   - Ensure all changes to your JavaScript and JSON files are saved.

Happy coding with Core Plugins!
